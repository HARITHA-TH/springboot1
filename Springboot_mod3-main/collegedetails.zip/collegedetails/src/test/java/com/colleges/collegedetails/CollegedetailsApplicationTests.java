package com.colleges.collegedetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegedetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
