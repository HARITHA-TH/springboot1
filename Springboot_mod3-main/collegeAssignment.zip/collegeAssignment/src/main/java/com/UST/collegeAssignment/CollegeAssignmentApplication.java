package com.UST.collegeAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeAssignmentApplication.class, args);
	}

}
