package com.UST.collegeAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
