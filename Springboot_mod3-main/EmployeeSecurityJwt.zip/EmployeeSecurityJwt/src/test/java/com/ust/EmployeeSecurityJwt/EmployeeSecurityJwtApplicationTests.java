package com.ust.EmployeeSecurityJwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSecurityJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
