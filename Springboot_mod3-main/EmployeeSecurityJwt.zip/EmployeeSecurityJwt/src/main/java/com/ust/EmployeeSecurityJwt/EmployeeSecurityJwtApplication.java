package com.ust.EmployeeSecurityJwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeSecurityJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeSecurityJwtApplication.class, args);
	}

}
