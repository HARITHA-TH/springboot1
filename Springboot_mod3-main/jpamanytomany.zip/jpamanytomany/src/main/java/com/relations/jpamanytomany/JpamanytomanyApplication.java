package com.relations.jpamanytomany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpamanytomanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpamanytomanyApplication.class, args);
	}

}
